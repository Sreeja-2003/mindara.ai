# Mindara - AI-powered Cognitive Behavioral Therapy Companion

Mindara is a web-based platform that offers personalized Cognitive Behavioral Therapy (CBT) exercises using AI. The platform analyzes users' moods and suggests tailored CBT activities to improve mental well-being.
