from flask import Flask, request, render_template, redirect, url_for
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import make_pipeline
import joblib

app = Flask(__name__)

# Load the dataset and create a model
file_path = 'IMDB Dataset.csv'
df = pd.read_csv(file_path)
df.dropna(inplace=True)

X = df['review']
y = df['sentiment']

# Train/Test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create a TF-IDF Vectorizer and Naive Bayes model pipeline
model = make_pipeline(TfidfVectorizer(), MultinomialNB())
model.fit(X_train, y_train)

# Save the model for later use
joblib.dump(model, 'sentiment_model.joblib')

# Load the trained model
model = joblib.load('sentiment_model.joblib')

@app.route('/')
def login():
    return render_template('login.html')

@app.route('/exercise', methods=['POST'])
def exercise():
    # Here you could add authentication
    return render_template('exercise.html')

@app.route('/analyze', methods=['POST'])
def analyze():
    user_thought = request.form['moodInput']
    positive_exercises = request.form.getlist('positive_exercises')
    negative_exercises = request.form.getlist('negative_exercises')
    
    # Analyze the thought
    predicted_category = model.predict([user_thought])[0]

    # Create a response based on predictions
    exercises = ""
    if predicted_category == 'positive':
        exercises = "Positive exercises: " + ", ".join(positive_exercises)
    elif predicted_category == 'negative':
        exercises = "Negative exercises: " + ", ".join(negative_exercises)
    
    return render_template('exercise.html', predicted_category=predicted_category, exercises=exercises)

if __name__ == "__main__":
    app.run(debug=True)
